/**
 * BookSwap — Render Functions
 * All page rendering logic
 */

// ─────────────────────────────────────────
// PAGE ROUTER
// ─────────────────────────────────────────
function renderPage(page, bookId) {
  switch(page) {
    case 'home':     renderHome();          break;
    case 'browse':   renderBrowse();        break;
    case 'detail':   renderBookDetail(bookId); break;
    case 'messages': renderMessages();      break;
    case 'profile':  renderProfile();       break;
    case 'add-book': renderAddBook();       break;
    case 'wishlist': renderWishlist();      break;
    case 'map':      renderMap();           break;
  }
}

// ─────────────────────────────────────────
// HOME PAGE
// ─────────────────────────────────────────
function renderHome() {
  // Nothing dynamic needed, already in HTML
  // Just update the featured books section dynamically
  renderFeaturedBooks();
}

function renderFeaturedBooks() {
  const grid = document.getElementById('featured-books-grid');
  if (!grid) return;
  const featured = AppState.books.slice(0, 6);
  grid.innerHTML = featured.map(book => renderBookCardHTML(book)).join('');
  attachBookCardEvents(grid);
}

// ─────────────────────────────────────────
// BROWSE PAGE
// ─────────────────────────────────────────
function renderBrowse() {
  renderBookGrid();
  updateBrowseCount();
}

function getFilteredBooks() {
  let books = [...AppState.books, ...AppState.myBooks];
  const q = AppState.searchQuery.toLowerCase();
  if (q) {
    books = books.filter(b =>
      b.title.toLowerCase().includes(q) ||
      b.author.toLowerCase().includes(q) ||
      b.genre.toLowerCase().includes(q)
    );
  }
  if (AppState.filters.types.length) {
    books = books.filter(b => AppState.filters.types.includes(b.type));
  }
  if (AppState.filters.genres.length) {
    books = books.filter(b => AppState.filters.genres.includes(b.genre));
  }
  if (AppState.filters.conditions.length) {
    books = books.filter(b => AppState.filters.conditions.includes(b.condition));
  }
  return books;
}

function renderBookGrid() {
  const grid = document.getElementById('books-grid');
  if (!grid) return;
  const books = getFilteredBooks();
  if (books.length === 0) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;padding:var(--space-16) 0;">
      <div class="empty-icon">📚</div>
      <h3>No books found</h3>
      <p>Try adjusting your search or filters</p>
      <button class="btn btn-primary" onclick="clearAllFilters()">Clear Filters</button>
    </div>`;
    return;
  }
  grid.className = `books-grid ${AppState.viewMode === 'list' ? 'list-view' : ''}`;
  grid.innerHTML = books.map(book => renderBookCardHTML(book)).join('');
  attachBookCardEvents(grid);
}

let uploadedCoverDataUrl = null;

function handleCoverImageUpload(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) {
    showToast('Photo size must be under 5MB', 'error');
    return;
  }
  const reader = new FileReader();
  reader.onload = function(e) {
    uploadedCoverDataUrl = e.target.result;
    const placeholder = document.getElementById('upload-placeholder-content');
    const previewContainer = document.getElementById('upload-preview-container');
    const previewImg = document.getElementById('upload-preview-img');
    if (placeholder && previewContainer && previewImg) {
      previewImg.src = uploadedCoverDataUrl;
      placeholder.classList.add('hidden');
      previewContainer.classList.remove('hidden');
    }
    showToast('Book photo attached! 📸', 'success');
  };
  reader.readAsDataURL(file);
}

function removeUploadedImage() {
  uploadedCoverDataUrl = null;
  const fileInput = document.getElementById('cover-file-input');
  if (fileInput) fileInput.value = '';
  const placeholder = document.getElementById('upload-placeholder-content');
  const previewContainer = document.getElementById('upload-preview-container');
  if (placeholder && previewContainer) {
    placeholder.classList.remove('hidden');
    previewContainer.classList.add('hidden');
  }
}

function renderBookCardHTML(book) {
  const inWishlist = AppState.wishlist.includes(book.id);
  const coverMedia = book.coverImage
    ? `<img src="${book.coverImage}" class="book-cover-img" alt="${book.title}" style="width:100%;height:100%;object-fit:cover" />`
    : `<div class="book-cover-placeholder">${book.coverEmoji || '📖'}</div>`;

  return `
  <article class="book-card" data-book-id="${book.id}" id="book-${book.id}">
    <div class="book-cover-wrap" style="background:${book.coverColor || '#EEF2FF'}">
      ${coverMedia}
      <div class="book-type-badge">${getTypeBadge(book.type, book.price)}</div>
      <button class="book-wishlist-btn ${inWishlist ? 'active' : ''}" data-book-id="${book.id}" id="wishlist-btn-${book.id}" aria-label="Add to wishlist">
        ${inWishlist ? '❤️' : '🤍'}
      </button>
    </div>
    <div class="book-card-body">
      <div class="book-title">${book.title}</div>
      <div class="book-author">by ${book.author}</div>
      <div class="book-meta">
        <div class="book-owner">
          <div class="owner-avatar-sm">${book.owner.initials}</div>
          ${book.owner.name.split(' ')[0]}
        </div>
        ${getConditionBadge(book.condition)}
      </div>
    </div>
    <div class="book-card-footer">
      <button class="btn btn-primary btn-sm" style="flex:1" data-view-book="${book.id}" id="view-btn-${book.id}">View Book</button>
      <button class="btn btn-ghost btn-sm btn-icon" data-wishlist-book="${book.id}">
        ${inWishlist ? '❤️' : '🤍'}
      </button>
    </div>
  </article>`;
}

function attachBookCardEvents(container) {
  // View book
  container.querySelectorAll('[data-view-book]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      navigateTo('detail', btn.dataset.viewBook);
    });
  });
  // Card click
  container.querySelectorAll('.book-card').forEach(card => {
    card.addEventListener('click', () => {
      navigateTo('detail', card.dataset.bookId);
    });
  });
  // Wishlist
  container.querySelectorAll('[data-wishlist-book], .book-wishlist-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const bookId = btn.dataset.wishlistBook || btn.dataset.bookId;
      toggleWishlist(bookId);
    });
  });
}

function updateBrowseCount() {
  const el = document.getElementById('browse-count');
  if (el) el.textContent = `${getFilteredBooks().length} books found`;
}

function clearAllFilters() {
  AppState.filters = { genres: [], types: [], conditions: [] };
  AppState.searchQuery = '';
  document.querySelectorAll('.filter-option input[type=checkbox]').forEach(cb => cb.checked = false);
  document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
  const searchInput = document.getElementById('nav-search-input');
  if (searchInput) searchInput.value = '';
  renderBrowse();
}

function toggleWishlist(bookId) {
  const idx = AppState.wishlist.indexOf(bookId);
  if (idx > -1) {
    AppState.wishlist.splice(idx, 1);
    showToast('Removed from wishlist', 'info');
  } else {
    AppState.wishlist.push(bookId);
    showToast('Added to wishlist ❤️', 'success');
  }
  saveState();
  // Update all wishlist buttons for this book
  document.querySelectorAll(`[data-wishlist-book="${bookId}"], [data-book-id="${bookId}"].book-wishlist-btn`).forEach(btn => {
    const inList = AppState.wishlist.includes(bookId);
    btn.textContent = inList ? '❤️' : '🤍';
    if (btn.classList.contains('book-wishlist-btn')) {
      btn.classList.toggle('active', inList);
    }
  });
  // Re-render wishlist if open
  if (AppState.currentPage === 'wishlist') renderWishlist();
}

// ─────────────────────────────────────────
// BOOK DETAIL PAGE
// ─────────────────────────────────────────
function renderBookDetail(bookId) {
  const book = AppState.books.find(b => b.id === bookId) || AppState.myBooks.find(b => b.id === bookId);
  const container = document.getElementById('book-detail-content');
  if (!book || !container) return;
  const inWishlist = AppState.wishlist.includes(book.id);
  const typeActions = {
    lend: `<button class="btn btn-primary btn-lg btn-block" onclick="openRequestModal('${book.id}', 'lend')">📖 Request to Borrow</button>`,
    swap: `<button class="btn btn-primary btn-lg btn-block" onclick="openRequestModal('${book.id}', 'swap')">🔄 Propose a Swap</button>`,
    give: `<button class="btn btn-primary btn-lg btn-block" onclick="openRequestModal('${book.id}', 'give')">🎁 Claim This Book</button>`,
    sell: `<button class="btn btn-primary btn-lg btn-block" style="background:var(--clr-sell);border-color:var(--clr-sell)" onclick="openRequestModal('${book.id}', 'sell')">💳 Buy Now (₹${book.price || 199})</button>`
  };

  const detailCover = book.coverImage
    ? `<img src="${book.coverImage}" alt="${book.title}" style="width:100%;max-height:360px;object-fit:cover;border-radius:var(--radius-xl);box-shadow:var(--shadow-lg);margin-bottom:var(--space-4)" />`
    : `<div class="book-cover-placeholder-lg" style="background:${book.coverColor || '#EEF2FF'}">${book.coverEmoji || '📖'}</div>`;

  container.innerHTML = `
  <div class="book-detail-layout">
    <aside class="book-detail-cover">
      ${detailCover}
      <div style="display:flex;gap:var(--space-3);flex-direction:column">
        <button class="btn btn-outline btn-block" onclick="toggleWishlist('${book.id}')">
          ${inWishlist ? '❤️ Remove from Wishlist' : '🤍 Add to Wishlist'}
        </button>
        <button class="btn btn-ghost btn-block" onclick="showToast('Share link copied!', 'success')">🔗 Share</button>
      </div>
    </aside>
    <div class="book-detail-main">
      <div style="display:flex;flex-wrap:wrap;gap:var(--space-3);margin-bottom:var(--space-4)">
        <button class="btn btn-ghost btn-sm" onclick="navigateTo('browse')">← Back to Browse</button>
      </div>
      <h1 class="book-detail-title">${book.title}</h1>
      <p class="book-detail-author">by <strong>${book.author}</strong></p>
      <div class="book-detail-meta">
        ${getTypeBadge(book.type, book.price)}
        ${getConditionBadge(book.condition)}
        <span class="badge" style="background:#F3F4F6;color:var(--clr-text-secondary)">📍 ${book.distance}</span>
        <span class="badge" style="background:#F3F4F6;color:var(--clr-text-secondary)">❤️ ${book.wishlistCount} wishlists</span>
      </div>
      <div class="book-detail-info-grid">
        <div class="book-info-item"><span class="book-info-label">Genre</span><span class="book-info-value">${book.genre}</span></div>
        <div class="book-info-item"><span class="book-info-label">Year</span><span class="book-info-value">${book.year}</span></div>
        <div class="book-info-item"><span class="book-info-label">Pages</span><span class="book-info-value">${book.pages}</span></div>
        <div class="book-info-item"><span class="book-info-label">Language</span><span class="book-info-value">${book.language}</span></div>
        ${book.isbn ? `<div class="book-info-item" style="grid-column:1/-1"><span class="book-info-label">ISBN</span><span class="book-info-value">${book.isbn}</span></div>` : ''}
      </div>
      <p class="book-detail-desc">${book.description}</p>
      ${book.tags && book.tags.length ? `<div style="display:flex;flex-wrap:wrap;gap:var(--space-2);margin-bottom:var(--space-6)">
        ${book.tags.map(t => `<span class="profile-tag">#${t}</span>`).join('')}
      </div>` : ''}

      <!-- Owner & Request Box -->
      <div class="request-box">
        <div class="owner-profile-row">
          <div class="owner-info">
            <div class="owner-avatar">${book.owner.initials}</div>
            <div>
              <div class="owner-name">${book.owner.name}</div>
              <div class="owner-location">📍 ${book.owner.city} &bull; ${book.distance} away</div>
              <div class="owner-rating" style="margin-top:4px">
                ${renderStars(book.owner.rating)}
                <span>${book.owner.rating}</span>
                <span style="font-size:var(--text-xs);color:var(--clr-text-muted);font-weight:400">(${book.owner.reviews} reviews)</span>
              </div>
            </div>
          </div>
          <button class="btn btn-outline btn-sm" onclick="openMessageModal('${book.id}')">💬 Message</button>
        </div>
        <div class="request-actions">
          ${typeActions[book.type] || ''}
        </div>
      </div>

      <!-- Reviews -->
      <div class="reviews-section">
        <div class="reviews-header">
          <h3 style="font-size:var(--text-xl);font-weight:700">Reviews</h3>
          <button class="btn btn-outline btn-sm" onclick="openReviewModal('${book.id}')">Write a Review</button>
        </div>
        ${book.reviews && book.reviews.length ? `
        <div class="reviews-summary">
          <span class="review-avg">${book.owner.rating}</span>
          <div>
            ${renderStars(book.owner.rating)}
            <div style="font-size:var(--text-sm);color:var(--clr-text-secondary);margin-top:2px">${book.reviews.length} review${book.reviews.length > 1 ? 's' : ''}</div>
          </div>
        </div>
        <div id="reviews-list">
          ${book.reviews.map(r => `
          <div class="review-item">
            <div class="review-header">
              <div class="reviewer-info">
                <div class="owner-avatar-sm" style="width:32px;height:32px;font-size:0.75rem">${r.initials}</div>
                <div>
                  <div class="reviewer-name">${r.user}</div>
                  ${renderStars(r.rating)}
                </div>
              </div>
              <span class="review-date">${r.date}</span>
            </div>
            <p class="review-text">${r.text}</p>
          </div>`).join('')}
        </div>` : `<div class="empty-state" style="padding:var(--space-10) 0;">
          <div class="empty-icon">⭐</div>
          <h3>No reviews yet</h3>
          <p>Be the first to leave a review after your exchange!</p>
        </div>`}
      </div>
    </div>
  </div>`;
}

// ─────────────────────────────────────────
// MESSAGES PAGE
// ─────────────────────────────────────────
function renderMessages() {
  renderConversationList();
  renderEmptyChat();
}

function renderConversationList() {
  const list = document.getElementById('conversation-list');
  if (!list) return;
  list.innerHTML = AppState.conversations.map(conv => `
  <div class="conversation-item ${AppState.activeConversation === conv.id ? 'active' : ''}"
       data-conv-id="${conv.id}" id="conv-${conv.id}"
       onclick="openConversation('${conv.id}')">
    <div class="conv-avatar">
      ${conv.user.initials}
      ${conv.user.online ? '<div class="conv-online"></div>' : ''}
    </div>
    <div class="conv-info">
      <div class="conv-name">
        <span>${conv.user.name}</span>
        <span class="conv-time">${conv.time}</span>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between">
        <div class="conv-preview">${conv.lastMessage}</div>
        ${conv.unread ? `<div class="conv-unread">${conv.unread}</div>` : ''}
      </div>
    </div>
  </div>`).join('');
}

function renderEmptyChat() {
  const area = document.getElementById('chat-area');
  if (!area) return;
  area.innerHTML = `
  <div class="chat-empty">
    <div class="empty-icon">💬</div>
    <p style="color:var(--clr-text-secondary)">Select a conversation to start messaging</p>
    <p style="font-size:var(--text-sm)">Connect with book owners to arrange exchanges</p>
  </div>`;
}

function openConversation(convId) {
  AppState.activeConversation = convId;
  const conv = AppState.conversations.find(c => c.id === convId);
  if (!conv) return;
  // Mark as read
  conv.unread = 0;
  renderConversationList();

  const area = document.getElementById('chat-area');
  if (!area) return;
  area.innerHTML = `
  <div class="chat-header">
    <div class="chat-header-user">
      <div class="conv-avatar">
        ${conv.user.initials}
        ${conv.user.online ? '<div class="conv-online"></div>' : ''}
      </div>
      <div>
        <div style="font-weight:700;font-size:var(--text-sm)">${conv.user.name}</div>
        <div style="font-size:var(--text-xs);color:var(--clr-text-muted)">${conv.user.online ? '🟢 Online' : 'Offline'}</div>
      </div>
    </div>
    <div style="display:flex;gap:var(--space-2)">
      <button class="btn btn-ghost btn-sm btn-icon" title="Call">📞</button>
      <button class="btn btn-ghost btn-sm btn-icon" title="More">⋯</button>
    </div>
  </div>
  <div class="chat-messages" id="chat-messages">
    <div class="chat-book-ref" onclick="navigateTo('detail', '${conv.bookRef ? AppState.books.find(b=>b.title===conv.bookRef.title)?.id : ''}')">
      <span style="font-size:1.5rem">${conv.bookRef?.type === 'swap' ? '🔄' : conv.bookRef?.type === 'give' ? '🎁' : '📖'}</span>
      <div>
        <div style="font-size:var(--text-xs);color:var(--clr-text-muted)">About this book</div>
        <div style="font-size:var(--text-sm);font-weight:700">${conv.bookRef?.title || 'Book Exchange'}</div>
      </div>
      <span style="margin-left:auto;font-size:var(--text-sm);color:var(--clr-primary)">→</span>
    </div>
    ${conv.messages.map(msg => `
    <div class="message-bubble ${msg.type}" id="msg-${msg.id}">
      ${msg.type === 'received' ? `<div class="bubble-avatar">${conv.user.initials}</div>` : ''}
      <div>
        <div class="bubble-content">${msg.text}</div>
        <div class="bubble-time">${msg.time}</div>
      </div>
    </div>`).join('')}
  </div>
  <div class="chat-input-area">
    <button class="btn btn-ghost btn-sm btn-icon" title="Attach">📎</button>
    <input type="text" class="chat-input" id="chat-input-field" placeholder="Type a message..." />
    <button class="chat-send-btn" id="chat-send-btn" onclick="sendMessage('${convId}')">➤</button>
  </div>`;

  // Enter key to send
  const input = document.getElementById('chat-input-field');
  if (input) {
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') sendMessage(convId);
    });
    input.focus();
  }
  // Scroll to bottom
  setTimeout(() => {
    const msgs = document.getElementById('chat-messages');
    if (msgs) msgs.scrollTop = msgs.scrollHeight;
  }, 50);
}

function sendMessage(convId) {
  const input = document.getElementById('chat-input-field');
  if (!input || !input.value.trim()) return;
  const text = input.value.trim();
  input.value = '';

  const conv = AppState.conversations.find(c => c.id === convId);
  if (!conv) return;

  const msg = { id: generateId(), from: 'me', text, time: 'Just now', type: 'sent' };
  conv.messages.push(msg);
  conv.lastMessage = text;
  conv.time = 'Just now';

  // Append message to chat
  const msgs = document.getElementById('chat-messages');
  if (msgs) {
    const div = document.createElement('div');
    div.className = 'message-bubble sent';
    div.id = `msg-${msg.id}`;
    div.innerHTML = `<div><div class="bubble-content">${text}</div><div class="bubble-time">Just now</div></div>`;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }
  // Simulate reply
  setTimeout(() => {
    const replies = [
      "That sounds great! Let's arrange a meet-up 😊",
      "Perfect! I'm available this weekend.",
      "Wonderful! I'll make sure the book is ready for you.",
      "Great choice! You're going to love it 📚",
      "Let me check my schedule and get back to you!"
    ];
    const reply = { id: generateId(), from: conv.user.id, text: replies[Math.floor(Math.random() * replies.length)], time: 'Just now', type: 'received' };
    conv.messages.push(reply);
    const div = document.createElement('div');
    div.className = 'message-bubble received';
    div.id = `msg-${reply.id}`;
    div.innerHTML = `<div class="bubble-avatar">${conv.user.initials}</div><div><div class="bubble-content">${reply.text}</div><div class="bubble-time">Just now</div></div>`;
    if (msgs) { msgs.appendChild(div); msgs.scrollTop = msgs.scrollHeight; }
    showToast(`${conv.user.name.split(' ')[0]} replied`, 'info');
  }, 1500);
}

// ─────────────────────────────────────────
// PROFILE PAGE
// ─────────────────────────────────────────
function renderProfile() {
  const user = AppState.currentUser;
  const profileData = user || {
    name: 'Book Explorer',
    initials: 'BE',
    email: 'bookexplorer@example.com',
    bio: 'Passionate reader and book sharer. I believe books are meant to be shared, not hoarded!',
    city: 'Mumbai',
    genres: ['Fiction', 'Sci-Fi', 'Psychology', 'History'],
    joined: 'September 2025',
    booksShared: AppState.myBooks.length || 3,
    exchanges: 28,
    reviews: 4.9
  };

  const container = document.getElementById('profile-content');
  if (!container) return;
  container.innerHTML = `
  <div class="profile-layout">
    <div class="profile-header-card">
      <div class="profile-cover">
        <div class="profile-avatar-wrap">
          <div class="profile-avatar">${profileData.initials}</div>
        </div>
      </div>
      <div class="profile-info">
        <div>
          <h1 class="profile-name">${profileData.name}</h1>
          <p class="profile-bio">${profileData.bio}</p>
          <div class="profile-tags">
            ${(profileData.genres || []).map(g => `<span class="profile-tag">${g}</span>`).join('')}
          </div>
        </div>
        <div>
          <div class="profile-stats">
            <div class="profile-stat">
              <span class="profile-stat-value">${profileData.booksShared || AppState.myBooks.length}</span>
              <span class="profile-stat-label">Books Shared</span>
            </div>
            <div class="profile-stat">
              <span class="profile-stat-value">${profileData.exchanges || 28}</span>
              <span class="profile-stat-label">Exchanges</span>
            </div>
            <div class="profile-stat">
              <span class="profile-stat-value">⭐ ${profileData.reviews || '4.9'}</span>
              <span class="profile-stat-label">Rating</span>
            </div>
          </div>
          <div style="display:flex;gap:var(--space-3);margin-top:var(--space-4)">
            <button class="btn btn-primary btn-sm" onclick="openEditProfileModal()">✏️ Edit Profile</button>
            <button class="btn btn-outline btn-sm" onclick="showToast('Profile link copied!', 'success')">🔗 Share Profile</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Tabs -->
    <div class="profile-tabs" role="tablist">
      <button class="profile-tab active" id="tab-my-books" role="tab" onclick="switchProfileTab('my-books')">📚 My Books (${AppState.myBooks.length})</button>
      <button class="profile-tab" id="tab-wishlist" role="tab" onclick="switchProfileTab('wishlist')">❤️ Wishlist (${AppState.wishlist.length})</button>
      <button class="profile-tab" id="tab-history" role="tab" onclick="switchProfileTab('history')">🕒 History</button>
      <button class="profile-tab" id="tab-reviews" role="tab" onclick="switchProfileTab('reviews')">⭐ Reviews</button>
    </div>

    <div id="profile-tab-content">
      ${renderProfileTabContent('my-books')}
    </div>
  </div>`;
}

function switchProfileTab(tab) {
  document.querySelectorAll('.profile-tab').forEach(t => t.classList.remove('active'));
  const activeTab = document.getElementById(`tab-${tab}`);
  if (activeTab) activeTab.classList.add('active');
  const content = document.getElementById('profile-tab-content');
  if (content) content.innerHTML = renderProfileTabContent(tab);
  if (tab === 'my-books') {
    const grid = document.getElementById('my-books-grid');
    if (grid) attachBookCardEvents(grid);
  }
}

function renderProfileTabContent(tab) {
  switch(tab) {
    case 'my-books':
      if (AppState.myBooks.length === 0) {
        return `<div class="empty-state">
          <div class="empty-icon">📚</div>
          <h3>No books listed yet</h3>
          <p>Start sharing your books with the community!</p>
          <button class="btn btn-primary" onclick="navigateTo('add-book')">+ List a Book</button>
        </div>`;
      }
      return `<div class="books-grid" id="my-books-grid">
        ${AppState.myBooks.map(b => renderBookCardHTML(b)).join('')}
      </div>`;
    case 'wishlist':
      const wishlistBooks = AppState.books.filter(b => AppState.wishlist.includes(b.id));
      if (wishlistBooks.length === 0) {
        return `<div class="empty-state">
          <div class="empty-icon">❤️</div>
          <h3>Your wishlist is empty</h3>
          <p>Browse books and heart the ones you'd love to read!</p>
          <button class="btn btn-primary" onclick="navigateTo('browse')">Browse Books</button>
        </div>`;
      }
      return `<div class="books-grid" id="my-books-grid">
        ${wishlistBooks.map(b => renderBookCardHTML(b)).join('')}
      </div>`;
    case 'history':
      return `<div style="display:flex;flex-direction:column;gap:var(--space-4)">
        ${[
          { icon: '📖', action: 'Borrowed', book: 'The Midnight Library', from: 'Priya Sharma', date: '2 weeks ago', status: 'Returned', statusColor: 'var(--clr-success)' },
          { icon: '🔄', action: 'Swapped', book: 'Deep Work', from: 'Arjun Patel', date: '1 month ago', status: 'Completed', statusColor: 'var(--clr-success)' },
          { icon: '🎁', action: 'Received', book: 'Psychology of Money', from: 'Ananya Gupta', date: '2 months ago', status: 'Completed', statusColor: 'var(--clr-success)' }
        ].map(h => `
        <div class="card" style="cursor:default">
          <div class="card-body" style="display:flex;align-items:center;gap:var(--space-4)">
            <div style="width:48px;height:48px;border-radius:var(--radius-lg);background:var(--clr-bg);display:flex;align-items:center;justify-content:center;font-size:1.5rem;flex-shrink:0">${h.icon}</div>
            <div style="flex:1">
              <div style="font-weight:700;font-size:var(--text-sm)">${h.action} "${h.book}"</div>
              <div style="font-size:var(--text-xs);color:var(--clr-text-secondary)">with ${h.from} &bull; ${h.date}</div>
            </div>
            <span style="font-size:var(--text-xs);font-weight:700;color:${h.statusColor}">${h.status}</span>
          </div>
        </div>`).join('')}
      </div>`;
    case 'reviews':
      return `<div style="display:flex;flex-direction:column;gap:0">
        ${[
          { user: 'Priya S.', initials: 'PS', rating: 5, date: '2 weeks ago', text: 'Excellent exchange! The book was in perfect condition and very prompt communication.' },
          { user: 'Arjun P.', initials: 'AP', rating: 5, date: '1 month ago', text: 'Great book exchanger. Highly recommended to the community!' },
          { user: 'Meera J.', initials: 'MJ', rating: 4, date: '2 months ago', text: 'Good experience overall. Book was well-maintained.' }
        ].map(r => `
        <div class="review-item">
          <div class="review-header">
            <div class="reviewer-info">
              <div class="owner-avatar-sm" style="width:32px;height:32px;font-size:0.75rem">${r.initials}</div>
              <div><div class="reviewer-name">${r.user}</div>${renderStars(r.rating)}</div>
            </div>
            <span class="review-date">${r.date}</span>
          </div>
          <p class="review-text">${r.text}</p>
        </div>`).join('')}
      </div>`;
    default: return '';
  }
}

// ─────────────────────────────────────────
// ADD BOOK PAGE
// ─────────────────────────────────────────
function renderAddBook() {
  // Nothing dynamic – form is in HTML
}

function submitAddBook(e) {
  e.preventDefault();
  const form = document.getElementById('add-book-form');
  const title = document.getElementById('book-title-input').value.trim();
  const author = document.getElementById('book-author-input').value.trim();
  const genre = document.getElementById('book-genre-input').value;
  const condition = document.getElementById('book-condition-input').value;
  const description = document.getElementById('book-desc-input').value.trim();
  const typeEl = document.querySelector('input[name="book-type"]:checked');
  const type = typeEl ? typeEl.value : 'lend';

  if (!title || !author) {
    showToast('Please fill in the required fields', 'error');
    return;
  }

  const priceInput = document.getElementById('book-price-input');
  const price = priceInput ? parseFloat(priceInput.value) || 0 : 0;

  const emojis = { Fiction: '📚', 'Sci-Fi': '🚀', History: '🌍', 'Self-Help': '⚡', Psychology: '🧠', Business: '💼', Finance: '💰', Classic: '⚖️', Memoir: '🎓' };
  const colors = { Fiction: '#EDE9FE', 'Sci-Fi': '#F0F9FF', History: '#ECFDF5', 'Self-Help': '#FEF3C7', Psychology: '#F5F3FF', Business: '#F0FDF4', Finance: '#F7FEE7', Classic: '#FFF1F2', Memoir: '#EFF6FF' };
  const user = AppState.currentUser || { name: 'You', initials: 'ME', city: 'Your City', rating: 5.0, reviews: 0 };

  const newBook = {
    id: generateId(),
    title, author, genre, condition, type, price, description,
    isbn: document.getElementById('book-isbn-input').value || '',
    year: parseInt(document.getElementById('book-year-input').value) || new Date().getFullYear(),
    pages: parseInt(document.getElementById('book-pages-input').value) || 0,
    language: document.getElementById('book-language-input').value || 'English',
    owner: { id: 'me', name: user.name, initials: user.initials, city: user.city, rating: user.rating || 5.0, reviews: user.reviews || 0 },
    distance: '0 km',
    coverImage: uploadedCoverDataUrl || null,
    coverEmoji: emojis[genre] || '📖',
    coverColor: colors[genre] || '#EEF2FF',
    wishlistCount: 0,
    tags: genre ? [genre.toLowerCase()] : [],
    reviews: []
  };

  AppState.myBooks.push(newBook);
  saveState();
  form.reset();
  removeUploadedImage();
  showToast(`"${title}" listed successfully with photo! 🎉`, 'success');
  setTimeout(() => navigateTo('browse'), 1500);
}

// ─────────────────────────────────────────
// WISHLIST PAGE
// ─────────────────────────────────────────
function renderWishlist() {
  const container = document.getElementById('wishlist-content');
  if (!container) return;
  const wishlistBooks = AppState.books.filter(b => AppState.wishlist.includes(b.id));
  if (wishlistBooks.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <div class="empty-icon">❤️</div>
      <h3>Your wishlist is empty</h3>
      <p>Browse books and tap the heart icon to save books you want to read!</p>
      <button class="btn btn-primary" onclick="navigateTo('browse')">Browse Books</button>
    </div>`;
    return;
  }
  container.innerHTML = `
  <div class="books-grid" id="wishlist-grid">
    ${wishlistBooks.map(b => renderBookCardHTML(b)).join('')}
  </div>`;
  const grid = document.getElementById('wishlist-grid');
  if (grid) attachBookCardEvents(grid);
}

// ─────────────────────────────────────────
// MAP PAGE
// ─────────────────────────────────────────
function renderMap() {
  renderMapBookList();
  renderMapPins();
}

function renderMapBookList() {
  const list = document.getElementById('map-books-list');
  if (!list) return;
  list.innerHTML = AppState.books.map(book => `
  <div class="map-book-item" onclick="navigateTo('detail', '${book.id}')">
    <div class="map-book-cover">${book.coverEmoji || '📖'}</div>
    <div class="map-book-info">
      <div class="map-book-title">${book.title}</div>
      <div class="map-book-author">by ${book.author}</div>
      <div style="display:flex;align-items:center;gap:var(--space-2);margin-top:var(--space-1)">
        ${getTypeBadge(book.type)}
        <span class="map-book-distance">📍 ${book.distance}</span>
      </div>
    </div>
  </div>`).join('');
}

function renderMapPins() {
  const mapContainer = document.getElementById('map-container');
  if (!mapContainer) return;
  // Clear existing pins
  mapContainer.querySelectorAll('.map-pin').forEach(p => p.remove());
  const positions = [
    [25, 35], [45, 20], [60, 55], [30, 65], [70, 30],
    [15, 50], [55, 75], [80, 45], [40, 80], [75, 65],
    [20, 25], [65, 15]
  ];
  AppState.books.forEach((book, i) => {
    const pos = positions[i % positions.length];
    const pin = document.createElement('div');
    pin.className = `map-pin ${book.type}`;
    pin.style.left = `${pos[0]}%`;
    pin.style.top = `${pos[1]}%`;
    pin.innerHTML = `<span>${book.coverEmoji || '📖'}</span><span class="map-pin-label">${book.title.split(' ').slice(0,3).join(' ')}</span>`;
    pin.addEventListener('click', () => navigateTo('detail', book.id));
    mapContainer.appendChild(pin);
  });
}
