/**
 * BookSwap — Application Data & State
 * Simulates a backend with localStorage persistence
 */

// ── Sample Book Data ──
const SAMPLE_BOOKS = [
  {
    id: 'b1',
    title: 'The Midnight Library',
    author: 'Matt Haig',
    genre: 'Fiction',
    condition: 'good',
    type: 'lend',
    isbn: '978-0525559474',
    year: 2020,
    pages: 288,
    language: 'English',
    description: 'A dazzling novel about all the choices that go into a life well lived. Between life and death there is a library, and within that library, the shelves go on forever.',
    owner: { id: 'u1', name: 'Priya Sharma', initials: 'PS', city: 'Mumbai', rating: 4.8, reviews: 23 },
    distance: '1.2 km',
    coverEmoji: '📚',
    coverColor: '#EDE9FE',
    wishlistCount: 12,
    tags: ['contemporary', 'fantasy', 'self-help'],
    reviews: [
      { user: 'Rahul M.', initials: 'RM', rating: 5, date: '2 weeks ago', text: 'Absolutely loved this book! Priya was very prompt and the book was in great condition.' },
      { user: 'Anika K.', initials: 'AK', rating: 4, date: '1 month ago', text: 'Great read, well looked after. Would definitely exchange with Priya again!' }
    ]
  },
  {
    id: 'b2',
    title: 'Atomic Habits',
    author: 'James Clear',
    genre: 'Self-Help',
    condition: 'new',
    type: 'swap',
    isbn: '978-0735211292',
    year: 2018,
    pages: 319,
    language: 'English',
    description: 'No matter your goals, Atomic Habits offers a proven framework for improving every day. James Clear reveals practical strategies that will teach you how to form good habits.',
    owner: { id: 'u2', name: 'Arjun Patel', initials: 'AP', city: 'Bangalore', rating: 4.9, reviews: 45 },
    distance: '0.8 km',
    coverEmoji: '⚡',
    coverColor: '#FEF3C7',
    wishlistCount: 28,
    tags: ['productivity', 'psychology', 'habits'],
    reviews: [
      { user: 'Sneha L.', initials: 'SL', rating: 5, date: '3 days ago', text: 'Arjun was super flexible with the exchange time. Highly recommended!' }
    ]
  },
  {
    id: 'b3',
    title: 'Sapiens',
    author: 'Yuval Noah Harari',
    genre: 'History',
    condition: 'good',
    type: 'give',
    isbn: '978-0062316097',
    year: 2015,
    pages: 443,
    language: 'English',
    description: 'A brief history of humankind. From the Stone Age to the 21st century, this book explores the full sweep of human history and how we came to dominate the planet.',
    owner: { id: 'u3', name: 'Kavya Reddy', initials: 'KR', city: 'Hyderabad', rating: 4.7, reviews: 18 },
    distance: '2.5 km',
    coverEmoji: '🌍',
    coverColor: '#ECFDF5',
    wishlistCount: 9,
    tags: ['history', 'science', 'anthropology'],
    reviews: []
  },
  {
    id: 'b4',
    title: 'The Alchemist',
    author: 'Paulo Coelho',
    genre: 'Fiction',
    condition: 'fair',
    type: 'lend',
    isbn: '978-0062315007',
    year: 1988,
    pages: 208,
    language: 'English',
    description: 'A magical story about a young Andalusian shepherd boy who yearns to travel in search of a worldly treasure. His quest will lead him to riches far different from what he ever imagined.',
    owner: { id: 'u4', name: 'Rohit Nair', initials: 'RN', city: 'Chennai', rating: 4.5, reviews: 31 },
    distance: '3.1 km',
    coverEmoji: '✨',
    coverColor: '#FFF7ED',
    wishlistCount: 15,
    tags: ['fiction', 'philosophy', 'inspirational'],
    reviews: []
  },
  {
    id: 'b5',
    title: 'Educated',
    author: 'Tara Westover',
    genre: 'Memoir',
    condition: 'new',
    type: 'swap',
    isbn: '978-0399590504',
    year: 2018,
    pages: 334,
    language: 'English',
    description: 'A memoir about a young girl who, kept out of school, leaves her survivalist family and goes on to earn a PhD from Cambridge University.',
    owner: { id: 'u5', name: 'Meera Joshi', initials: 'MJ', city: 'Pune', rating: 5.0, reviews: 8 },
    distance: '4.7 km',
    coverEmoji: '🎓',
    coverColor: '#EFF6FF',
    wishlistCount: 21,
    tags: ['memoir', 'biography', 'education'],
    reviews: []
  },
  {
    id: 'b6',
    title: 'Project Hail Mary',
    author: 'Andy Weir',
    genre: 'Sci-Fi',
    condition: 'good',
    type: 'lend',
    isbn: '978-0593135204',
    year: 2021,
    pages: 476,
    language: 'English',
    description: 'A lone astronaut must save the earth from disaster in this incredible new science-based thriller from the author of The Martian.',
    owner: { id: 'u6', name: 'Vikram Singh', initials: 'VS', city: 'Delhi', rating: 4.6, reviews: 12 },
    distance: '1.8 km',
    coverEmoji: '🚀',
    coverColor: '#F0F9FF',
    wishlistCount: 17,
    tags: ['sci-fi', 'space', 'thriller'],
    reviews: []
  },
  {
    id: 'b7',
    title: 'The Psychology of Money',
    author: 'Morgan Housel',
    genre: 'Finance',
    condition: 'new',
    type: 'give',
    isbn: '978-0857197689',
    year: 2020,
    pages: 256,
    language: 'English',
    description: 'Timeless lessons on wealth, greed, and happiness. Doing well with money isn\'t about what you know. It\'s about how you behave.',
    owner: { id: 'u7', name: 'Ananya Gupta', initials: 'AG', city: 'Kolkata', rating: 4.9, reviews: 29 },
    distance: '0.5 km',
    coverEmoji: '💰',
    coverColor: '#F7FEE7',
    wishlistCount: 33,
    tags: ['finance', 'psychology', 'investing'],
    reviews: []
  },
  {
    id: 'b8',
    title: 'Dune',
    author: 'Frank Herbert',
    genre: 'Sci-Fi',
    condition: 'good',
    type: 'swap',
    isbn: '978-0441013593',
    year: 1965,
    pages: 688,
    language: 'English',
    description: 'Set in the distant future amidst a feudal interstellar society, Dune tells the story of young Paul Atreides, heir to a noble family tasked with ruling an inhospitable world.',
    owner: { id: 'u8', name: 'Kiran Bose', initials: 'KB', city: 'Mumbai', rating: 4.4, reviews: 7 },
    distance: '6.2 km',
    coverEmoji: '🏜️',
    coverColor: '#FEF3C7',
    wishlistCount: 11,
    tags: ['sci-fi', 'classic', 'fantasy'],
    reviews: []
  },
  {
    id: 'b9',
    title: 'To Kill a Mockingbird',
    author: 'Harper Lee',
    genre: 'Classic',
    condition: 'fair',
    type: 'lend',
    isbn: '978-0061743528',
    year: 1960,
    pages: 324,
    language: 'English',
    description: 'A Pulitzer Prize-winning masterwork of honor and injustice in the deep South—and the heroism of one man in the face of blind and violent hatred.',
    owner: { id: 'u9', name: 'Divya Menon', initials: 'DM', city: 'Kochi', rating: 4.8, reviews: 41 },
    distance: '2.0 km',
    coverEmoji: '⚖️',
    coverColor: '#FFF1F2',
    wishlistCount: 6,
    tags: ['classic', 'fiction', 'legal'],
    reviews: []
  },
  {
    id: 'b10',
    title: 'The Lean Startup',
    author: 'Eric Ries',
    genre: 'Business',
    condition: 'good',
    type: 'swap',
    isbn: '978-0307887894',
    year: 2011,
    pages: 296,
    language: 'English',
    description: 'How today\'s entrepreneurs use continuous innovation to create radically successful businesses. A methodology for developing businesses and products.',
    owner: { id: 'u10', name: 'Siddharth Ray', initials: 'SR', city: 'Bangalore', rating: 4.7, reviews: 15 },
    distance: '5.4 km',
    coverEmoji: '🚀',
    coverColor: '#F0FDF4',
    wishlistCount: 8,
    tags: ['business', 'startup', 'entrepreneurship'],
    reviews: []
  },
  {
    id: 'b11',
    title: 'Normal People',
    author: 'Sally Rooney',
    genre: 'Fiction',
    condition: 'new',
    type: 'lend',
    isbn: '978-0571334650',
    year: 2018,
    pages: 273,
    language: 'English',
    description: 'A story about how one person can take you out of the life you\'ve planned for yourself, even when you don\'t realise it.',
    owner: { id: 'u11', name: 'Pooja Iyer', initials: 'PI', city: 'Mumbai', rating: 4.6, reviews: 22 },
    distance: '1.5 km',
    coverEmoji: '💙',
    coverColor: '#EFF6FF',
    wishlistCount: 14,
    tags: ['contemporary', 'romance', 'literary'],
    reviews: []
  },
  {
    id: 'b12',
    title: 'Thinking, Fast and Slow',
    author: 'Daniel Kahneman',
    genre: 'Psychology',
    condition: 'good',
    type: 'give',
    isbn: '978-0374533557',
    year: 2011,
    pages: 499,
    language: 'English',
    description: 'The two systems that drive the way we think and make choices. System 1 is fast, intuitive, and emotional; System 2 is slower, more deliberative, and more logical.',
    owner: { id: 'u12', name: 'Nikhil Das', initials: 'ND', city: 'Ahmedabad', rating: 4.9, reviews: 37 },
    distance: '3.8 km',
    coverEmoji: '🧠',
    coverColor: '#F5F3FF',
    wishlistCount: 25,
    tags: ['psychology', 'science', 'decision-making'],
    reviews: []
  },
  {
    id: 'b13',
    title: 'Design Patterns',
    author: 'Erich Gamma et al.',
    genre: 'Business',
    condition: 'good',
    type: 'sell',
    price: 299,
    isbn: '978-0201633610',
    year: 1994,
    pages: 395,
    language: 'English',
    description: 'Elements of Reusable Object-Oriented Software. Classic software design pattern guide in pristine condition.',
    owner: { id: 'u13', name: 'Aakash Verma', initials: 'AV', city: 'Bangalore', rating: 4.9, reviews: 14 },
    distance: '1.0 km',
    coverEmoji: '💻',
    coverColor: '#FFF7ED',
    wishlistCount: 35,
    tags: ['programming', 'software', 'design-patterns'],
    reviews: []
  },
  {
    id: 'b14',
    title: 'Atomic Habits (Special Edition)',
    author: 'James Clear',
    genre: 'Self-Help',
    condition: 'new',
    type: 'sell',
    price: 199,
    isbn: '978-0735211292',
    year: 2018,
    pages: 319,
    language: 'English',
    description: 'Brand new hardcover copy. Perfect condition, quick home pickup or delivery available.',
    owner: { id: 'u2', name: 'Arjun Patel', initials: 'AP', city: 'Bangalore', rating: 4.9, reviews: 45 },
    distance: '0.8 km',
    coverEmoji: '⚡',
    coverColor: '#FEF3C7',
    wishlistCount: 42,
    tags: ['productivity', 'habits', 'best-seller'],
    reviews: []
  }
];

// ── Sample Conversations ──
const SAMPLE_CONVERSATIONS = [
  {
    id: 'c1',
    user: { id: 'u1', name: 'Priya Sharma', initials: 'PS', online: true },
    bookRef: { title: 'The Midnight Library', type: 'lend' },
    lastMessage: 'Sure! I can drop it off at the library near you tomorrow?',
    time: '2m ago',
    unread: 2,
    messages: [
      { id: 'm1', from: 'u1', text: 'Hi! I saw you listed The Midnight Library. I\'ve been wanting to read it!', time: '10:15 AM', type: 'received' },
      { id: 'm2', from: 'me', text: 'Yes, it\'s available! Are you looking to borrow it?', time: '10:18 AM', type: 'sent' },
      { id: 'm3', from: 'u1', text: 'That would be amazing. How long can I keep it?', time: '10:20 AM', type: 'received' },
      { id: 'm4', from: 'me', text: 'Up to 3 weeks works for me. Where are you located?', time: '10:22 AM', type: 'sent' },
      { id: 'm5', from: 'u1', text: 'Sure! I can drop it off at the library near you tomorrow?', time: '10:25 AM', type: 'received' }
    ]
  },
  {
    id: 'c2',
    user: { id: 'u2', name: 'Arjun Patel', initials: 'AP', online: false },
    bookRef: { title: 'Atomic Habits', type: 'swap' },
    lastMessage: 'I have "Deep Work" by Cal Newport, would that work for a swap?',
    time: '1h ago',
    unread: 0,
    messages: [
      { id: 'm1', from: 'u2', text: 'Hey! I\'m interested in swapping Atomic Habits.', time: 'Yesterday' , type: 'received' },
      { id: 'm2', from: 'me', text: 'Great! What would you like to swap it for?', time: 'Yesterday', type: 'sent' },
      { id: 'm3', from: 'u2', text: 'I have "Deep Work" by Cal Newport, would that work for a swap?', time: '1h ago', type: 'received' }
    ]
  },
  {
    id: 'c3',
    user: { id: 'u7', name: 'Ananya Gupta', initials: 'AG', online: true },
    bookRef: { title: 'Psychology of Money', type: 'give' },
    lastMessage: 'Thank you so much for the book! It was a wonderful read. 📚',
    time: '3h ago',
    unread: 0,
    messages: [
      { id: 'm1', from: 'me', text: 'Hi Ananya, I\'d love to have The Psychology of Money!', time: '3h ago', type: 'sent' },
      { id: 'm2', from: 'u7', text: 'Of course! I\'ll leave it at the front desk with your name.', time: '3h ago', type: 'received' },
      { id: 'm3', from: 'u7', text: 'Thank you so much for the book! It was a wonderful read. 📚', time: '2h ago', type: 'received' }
    ]
  }
];

// ── App State ──
const AppState = {
  currentUser: null,
  books: [...SAMPLE_BOOKS],
  wishlist: [],
  conversations: [...SAMPLE_CONVERSATIONS],
  activeConversation: null,
  filters: { genres: [], types: [], conditions: [] },
  searchQuery: '',
  currentPage: 'home',
  currentBookId: null,
  viewMode: 'grid',
  notifications: [
    { id: 'n1', icon: '📩', text: '<strong>Priya Sharma</strong> sent you a message about The Midnight Library', time: '2m ago', unread: true },
    { id: 'n2', icon: '🔄', text: '<strong>Arjun Patel</strong> wants to swap Atomic Habits with you', time: '1h ago', unread: true },
    { id: 'n3', icon: '❤️', text: '<strong>3 people</strong> wishlisted your book "Sapiens"', time: '3h ago', unread: false },
    { id: 'n4', icon: '⭐', text: '<strong>Kavya Reddy</strong> left you a 5-star review', time: '1d ago', unread: false }
  ],
  myBooks: []
};

// ── Storage Helpers ──
function saveState() {
  try {
    localStorage.setItem('bookswap_wishlist', JSON.stringify(AppState.wishlist));
    localStorage.setItem('bookswap_user', JSON.stringify(AppState.currentUser));
    localStorage.setItem('bookswap_mybooks', JSON.stringify(AppState.myBooks));
  } catch(e) {}
}
function loadState() {
  try {
    const wishlist = localStorage.getItem('bookswap_wishlist');
    const user = localStorage.getItem('bookswap_user');
    const myBooks = localStorage.getItem('bookswap_mybooks');
    if (wishlist) AppState.wishlist = JSON.parse(wishlist);
    if (user) AppState.currentUser = JSON.parse(user);
    if (myBooks) AppState.myBooks = JSON.parse(myBooks);
  } catch(e) {}
}

// ── Utility Functions ──
function generateId() { return Math.random().toString(36).substr(2, 9); }

function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  toast.innerHTML = `<span>${icons[type] || '💬'}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('fade-out');
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

function navigateTo(page, bookId = null) {
  AppState.currentPage = page;
  AppState.currentBookId = bookId;
  // hide all sections
  document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
  // show target
  const target = document.getElementById(`page-${page}`);
  if (target) {
    target.classList.add('active');
    target.classList.add('fade-in');
    setTimeout(() => target.classList.remove('fade-in'), 500);
  }
  // update nav active states
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
  const activeLink = document.querySelector(`[data-page="${page}"]`);
  if (activeLink) activeLink.classList.add('active');
  // scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
  // trigger page-specific rendering
  renderPage(page, bookId);
}

function getTypeBadge(type, price = null) {
  const map = {
    lend: ['badge-lend', '📖 Lend'],
    swap: ['badge-swap', '🔄 Swap'],
    give: ['badge-give', '🎁 Give Away'],
    sell: ['badge-sell', price ? `🏷️ Sell ₹${price}` : '🏷️ Sell']
  };
  const [cls, label] = map[type] || ['badge-lend', type];
  return `<span class="badge ${cls}">${label}</span>`;
}
function getConditionBadge(cond) {
  const map = { new: ['badge-new', '✨ New'], good: ['badge-good', '👍 Good'], fair: ['badge-fair', '👌 Fair'] };
  const [cls, label] = map[cond] || ['badge-good', cond];
  return `<span class="badge ${cls}">${label}</span>`;
}
function renderStars(rating) {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;
  let s = '';
  for (let i = 0; i < full; i++) s += '★';
  if (half) s += '☆';
  for (let i = 0; i < 5 - full - (half ? 1 : 0); i++) s += '☆';
  return `<span class="stars">${s}</span>`;
}
