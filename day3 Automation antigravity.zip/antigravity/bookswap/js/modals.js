/**
 * BookSwap — Modals & UI Interactions
 */

// ─────────────────────────────────────────
// AUTH MODAL
// ─────────────────────────────────────────
function openAuthModal(tab = 'login') {
  const overlay = document.getElementById('auth-modal-overlay');
  if (!overlay) return;
  overlay.classList.remove('hidden');
  switchAuthTab(tab);
}

function closeAuthModal() {
  const overlay = document.getElementById('auth-modal-overlay');
  if (overlay) overlay.classList.add('hidden');
}

function switchAuthTab(tab) {
  document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.auth-form').forEach(f => f.classList.add('hidden'));
  const activeTab = document.getElementById(`auth-tab-${tab}`);
  const activeForm = document.getElementById(`auth-form-${tab}`);
  if (activeTab) activeTab.classList.add('active');
  if (activeForm) activeForm.classList.remove('hidden');
}

function submitLogin(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  if (!email || !password) { showToast('Please fill in all fields', 'error'); return; }
  // Simulate login
  const name = email.split('@')[0];
  const initials = name.split('.').map(n => n[0]?.toUpperCase()).join('').slice(0, 2) || 'U';
  AppState.currentUser = {
    name: name.charAt(0).toUpperCase() + name.slice(1),
    initials,
    email,
    bio: 'Passionate book lover and sharer!',
    city: 'Your City',
    genres: ['Fiction', 'Self-Help'],
    joined: 'September 2026',
    booksShared: 0,
    exchanges: 0,
    reviews: 5.0
  };
  saveState();
  updateNavForAuth();
  closeAuthModal();
  showToast(`Welcome back! 👋`, 'success');
  navigateTo('home');
}

function submitSignup(e) {
  e.preventDefault();
  const name = document.getElementById('signup-name').value.trim();
  const email = document.getElementById('signup-email').value;
  const password = document.getElementById('signup-password').value;
  if (!name || !email || !password) { showToast('Please fill in all fields', 'error'); return; }
  if (password.length < 6) { showToast('Password must be at least 6 characters', 'error'); return; }
  const initials = name.split(' ').map(n => n[0]?.toUpperCase()).join('').slice(0, 2) || 'U';
  AppState.currentUser = {
    name, initials, email,
    bio: 'New to BookSwap! Excited to share and discover books.',
    city: 'Your City',
    genres: [],
    joined: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
    booksShared: 0, exchanges: 0, reviews: 5.0
  };
  saveState();
  updateNavForAuth();
  closeAuthModal();
  showToast(`Welcome to BookSwap, ${name.split(' ')[0]}! 🎉`, 'success');
  navigateTo('home');
}

function logOut() {
  AppState.currentUser = null;
  saveState();
  updateNavForAuth();
  showToast('You have been logged out', 'info');
  navigateTo('home');
}

function updateNavForAuth() {
  const user = AppState.currentUser;
  const loginBtn = document.getElementById('nav-login-btn');
  const signupBtn = document.getElementById('nav-signup-btn');
  const avatarBtn = document.getElementById('nav-avatar-btn');
  const logoutBtn = document.getElementById('nav-logout-btn');
  const addBookBtn = document.getElementById('nav-add-book-btn');

  if (user) {
    if (loginBtn) loginBtn.classList.add('hidden');
    if (signupBtn) signupBtn.classList.add('hidden');
    if (avatarBtn) { avatarBtn.classList.remove('hidden'); avatarBtn.textContent = user.initials; }
    if (logoutBtn) logoutBtn.classList.remove('hidden');
  } else {
    if (loginBtn) loginBtn.classList.remove('hidden');
    if (signupBtn) signupBtn.classList.remove('hidden');
    if (avatarBtn) avatarBtn.classList.add('hidden');
    if (logoutBtn) logoutBtn.classList.add('hidden');
  }
  if (addBookBtn) addBookBtn.classList.remove('hidden');
}

// ─────────────────────────────────────────
// INTENT SELECTION MODAL
// ─────────────────────────────────────────
function openIntentModal() {
  const overlay = document.getElementById('intent-overlay');
  if (overlay) overlay.classList.remove('hidden');
}

function closeIntentModal() {
  const overlay = document.getElementById('intent-overlay');
  if (overlay) overlay.classList.add('hidden');
  try { sessionStorage.setItem('bookswap_intent_done', 'true'); } catch(e) {}
}

function handleIntentSelection(intent) {
  closeIntentModal();
  switch(intent) {
    case 'sell':
      showToast('Redirecting to list your book for sale... 🏷️', 'info');
      navigateTo('add-book');
      setTimeout(() => {
        const radio = document.querySelector('input[name="book-type"][value="sell"]');
        if (radio) {
          radio.checked = true;
          togglePriceFieldVisibility();
        }
      }, 150);
      break;
    case 'buy':
      showToast('Showing books available to buy! 🛒', 'info');
      setTypeFilter('sell');
      navigateTo('browse');
      break;
    case 'swap':
      showToast('Showing books available for swap! 🔄', 'info');
      setTypeFilter('swap');
      navigateTo('browse');
      break;
    case 'gift':
      showToast('Showing free books to claim! 🎁', 'info');
      setTypeFilter('give');
      navigateTo('browse');
      break;
    default:
      navigateTo('browse');
      break;
  }
}

// ─────────────────────────────────────────
// REQUEST MODAL (Borrow/Swap/Give/Sell)
// ─────────────────────────────────────────
function openRequestModal(bookId, type) {
  if (!AppState.currentUser) {
    showToast('Please log in to request or buy a book', 'error');
    openAuthModal('login');
    return;
  }
  const book = AppState.books.find(b => b.id === bookId) || AppState.myBooks.find(b => b.id === bookId);
  if (!book) return;
  const overlay = document.getElementById('request-modal-overlay');
  if (!overlay) return;
  const titles = { lend: 'Request to Borrow', swap: 'Propose a Swap', give: 'Claim This Book', sell: 'Purchase Book' };
  document.getElementById('request-modal-title').textContent = titles[type] || 'Request Book';
  document.getElementById('request-modal-book-title').textContent = book.title;
  document.getElementById('request-modal-book-author').textContent = `by ${book.author}`;
  document.getElementById('request-modal-book-emoji').textContent = book.coverEmoji || '📖';

  const swapSection = document.getElementById('request-swap-section');
  if (swapSection) swapSection.style.display = type === 'swap' ? 'block' : 'none';
  const lendSection = document.getElementById('request-lend-section');
  if (lendSection) lendSection.style.display = type === 'lend' ? 'block' : 'none';
  const sellSection = document.getElementById('request-sell-section');
  if (sellSection) {
    sellSection.style.display = type === 'sell' ? 'block' : 'none';
    const priceEl = document.getElementById('request-sell-price');
    if (priceEl) priceEl.textContent = `₹${book.price || 199}`;
  }

  const submitBtn = document.getElementById('request-submit-btn');
  if (submitBtn) {
    submitBtn.textContent = type === 'sell' ? `Pay ₹${book.price || 199} & Confirm 💳` : 'Send Request 🚀';
  }

  overlay.dataset.bookId = bookId;
  overlay.dataset.type = type;
  overlay.classList.remove('hidden');
}

function submitRequest() {
  const overlay = document.getElementById('request-modal-overlay');
  if (!overlay) return;
  const bookId = overlay.dataset.bookId;
  const type = overlay.dataset.type;
  const book = AppState.books.find(b => b.id === bookId);
  if (!book) return;

  const messages = {
    lend: `Hi! I'd love to borrow "${book.title}" from you.`,
    swap: `Hi! I'd like to swap books with you for "${book.title}".`,
    give: `Hi! I'd love to receive "${book.title}" from you as a giveaway!`,
    sell: `Hi! I would like to buy "${book.title}" for ₹${book.price || 199}. I've submitted my purchase order!`
  };

  // Create conversation
  const existingConv = AppState.conversations.find(c => c.user.id === book.owner.id);
  if (!existingConv) {
    const newConv = {
      id: generateId(),
      user: { id: book.owner.id, name: book.owner.name, initials: book.owner.initials, online: Math.random() > 0.5 },
      bookRef: { title: book.title, type },
      lastMessage: messages[type],
      time: 'Just now',
      unread: 0,
      messages: [{ id: generateId(), from: 'me', text: messages[type], time: 'Just now', type: 'sent' }]
    };
    AppState.conversations.unshift(newConv);
  }

  closeRequestModal();
  const toastMsg = type === 'sell'
    ? `Purchase order sent to ${book.owner.name.split(' ')[0]}! 💳`
    : `Request sent to ${book.owner.name.split(' ')[0]}! 🎉`;
  showToast(toastMsg, 'success');
  setTimeout(() => navigateTo('messages'), 1000);
}

function closeRequestModal() {
  const overlay = document.getElementById('request-modal-overlay');
  if (overlay) overlay.classList.add('hidden');
}

// ─────────────────────────────────────────
// MESSAGE MODAL (Quick message)
// ─────────────────────────────────────────
function openMessageModal(bookId) {
  if (!AppState.currentUser) {
    showToast('Please log in to send a message', 'error');
    openAuthModal('login');
    return;
  }
  const book = AppState.books.find(b => b.id === bookId) || AppState.myBooks.find(b => b.id === bookId);
  if (!book) return;

  const overlay = document.getElementById('message-modal-overlay');
  if (!overlay) return;
  document.getElementById('message-modal-owner').textContent = book.owner.name;
  overlay.dataset.bookId = bookId;
  overlay.classList.remove('hidden');
  const input = document.getElementById('message-modal-input');
  if (input) {
    input.value = `Hi ${book.owner.name.split(' ')[0]}! I'm interested in your book "${book.title}".`;
    input.focus();
  }
}

function submitQuickMessage() {
  const overlay = document.getElementById('message-modal-overlay');
  if (!overlay) return;
  const bookId = overlay.dataset.bookId;
  const book = AppState.books.find(b => b.id === bookId);
  const text = document.getElementById('message-modal-input').value.trim();
  if (!text || !book) return;

  const existingConv = AppState.conversations.find(c => c.user.id === book.owner.id);
  if (!existingConv) {
    const newConv = {
      id: generateId(),
      user: { id: book.owner.id, name: book.owner.name, initials: book.owner.initials, online: true },
      bookRef: { title: book.title, type: book.type },
      lastMessage: text,
      time: 'Just now',
      unread: 0,
      messages: [{ id: generateId(), from: 'me', text, time: 'Just now', type: 'sent' }]
    };
    AppState.conversations.unshift(newConv);
  } else {
    existingConv.messages.push({ id: generateId(), from: 'me', text, time: 'Just now', type: 'sent' });
    existingConv.lastMessage = text;
    existingConv.time = 'Just now';
  }

  closeMessageModal();
  showToast(`Message sent to ${book.owner.name.split(' ')[0]}! ✉️`, 'success');
  setTimeout(() => navigateTo('messages'), 800);
}

function closeMessageModal() {
  const overlay = document.getElementById('message-modal-overlay');
  if (overlay) overlay.classList.add('hidden');
}

// ─────────────────────────────────────────
// REVIEW MODAL
// ─────────────────────────────────────────
function openReviewModal(bookId) {
  if (!AppState.currentUser) {
    showToast('Please log in to leave a review', 'error');
    openAuthModal('login');
    return;
  }
  const overlay = document.getElementById('review-modal-overlay');
  if (!overlay) return;
  overlay.dataset.bookId = bookId;
  overlay.classList.remove('hidden');
  setupStarRating();
}

function setupStarRating() {
  let selectedRating = 5;
  const stars = document.querySelectorAll('.star-rating-btn');
  function updateStars(rating) {
    stars.forEach((s, i) => {
      s.textContent = i < rating ? '★' : '☆';
      s.style.color = i < rating ? 'var(--clr-accent)' : 'var(--clr-border)';
    });
    selectedRating = rating;
  }
  updateStars(5);
  stars.forEach((s, i) => {
    s.addEventListener('click', () => { selectedRating = i + 1; updateStars(selectedRating); });
    s.addEventListener('mouseenter', () => updateStars(i + 1));
    s.addEventListener('mouseleave', () => updateStars(selectedRating));
  });
  document.getElementById('review-submit-btn').onclick = () => submitReview(selectedRating);
}

function submitReview(rating) {
  const overlay = document.getElementById('review-modal-overlay');
  if (!overlay) return;
  const bookId = overlay.dataset.bookId;
  const text = document.getElementById('review-text-input').value.trim();
  if (!text) { showToast('Please write a review', 'error'); return; }
  const book = AppState.books.find(b => b.id === bookId);
  const user = AppState.currentUser;
  if (book && user) {
    if (!book.reviews) book.reviews = [];
    book.reviews.unshift({
      user: user.name,
      initials: user.initials,
      rating,
      date: 'Just now',
      text
    });
  }
  document.getElementById('review-text-input').value = '';
  overlay.classList.add('hidden');
  showToast('Review submitted! ⭐', 'success');
  if (AppState.currentPage === 'detail') renderBookDetail(bookId);
}

function closeReviewModal() {
  const overlay = document.getElementById('review-modal-overlay');
  if (overlay) overlay.classList.add('hidden');
}

// ─────────────────────────────────────────
// EDIT PROFILE MODAL
// ─────────────────────────────────────────
function openEditProfileModal() {
  const overlay = document.getElementById('edit-profile-modal-overlay');
  if (!overlay) return;
  const user = AppState.currentUser;
  if (user) {
    document.getElementById('edit-name').value = user.name || '';
    document.getElementById('edit-bio').value = user.bio || '';
    document.getElementById('edit-city').value = user.city || '';
  }
  overlay.classList.remove('hidden');
}

function submitEditProfile(e) {
  e.preventDefault();
  if (!AppState.currentUser) return;
  AppState.currentUser.name = document.getElementById('edit-name').value.trim() || AppState.currentUser.name;
  AppState.currentUser.bio = document.getElementById('edit-bio').value.trim();
  AppState.currentUser.city = document.getElementById('edit-city').value.trim();
  AppState.currentUser.initials = AppState.currentUser.name.split(' ').map(n => n[0]?.toUpperCase()).join('').slice(0, 2);
  saveState();
  updateNavForAuth();
  closeEditProfileModal();
  showToast('Profile updated! ✅', 'success');
  if (AppState.currentPage === 'profile') renderProfile();
}

function closeEditProfileModal() {
  const overlay = document.getElementById('edit-profile-modal-overlay');
  if (overlay) overlay.classList.add('hidden');
}

// ─────────────────────────────────────────
// NOTIFICATION DROPDOWN
// ─────────────────────────────────────────
function toggleNotifDropdown() {
  const dropdown = document.getElementById('notif-dropdown');
  if (!dropdown) return;
  dropdown.classList.toggle('hidden');
}

function renderNotifDropdown() {
  const list = document.getElementById('notif-list');
  if (!list) return;
  list.innerHTML = AppState.notifications.map(n => `
  <div class="notif-item ${n.unread ? 'unread' : ''}" onclick="markNotifRead('${n.id}')">
    <div class="notif-icon">${n.icon}</div>
    <div>
      <div class="notif-text">${n.text}</div>
      <div class="notif-time">${n.time}</div>
    </div>
  </div>`).join('');
  // Update badge count
  const unread = AppState.notifications.filter(n => n.unread).length;
  const badge = document.getElementById('notif-count');
  if (badge) { badge.textContent = unread; badge.style.display = unread ? 'flex' : 'none'; }
}

function markNotifRead(id) {
  const notif = AppState.notifications.find(n => n.id === id);
  if (notif) notif.unread = false;
  renderNotifDropdown();
}

function markAllNotifsRead() {
  AppState.notifications.forEach(n => n.unread = false);
  renderNotifDropdown();
}

// ─────────────────────────────────────────
// GLOBAL MODAL CLOSE ON OVERLAY CLICK
// ─────────────────────────────────────────
document.addEventListener('click', (e) => {
  // Close dropdowns when clicking outside
  if (!e.target.closest('#notif-btn-wrap')) {
    const dropdown = document.getElementById('notif-dropdown');
    if (dropdown) dropdown.classList.add('hidden');
  }
  // Close modal overlays on outside click
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.add('hidden');
  }
});
